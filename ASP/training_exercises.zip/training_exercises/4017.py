x = True
y = False

print(x) 
print(y)  

# استفاده در مقایسه‌ها :
a = 5
b = 10
result = a > b
print(result)

# استفاده در شرایط شرطی :
is_raning = False
if is_raning:
    print("is raning")
else :
    print("is not raning")

# تبدیل انواع داده‌ها به نوع بولی :
print(bool(''))
print(bool("hello"))
print(bool([1,2,3]))
