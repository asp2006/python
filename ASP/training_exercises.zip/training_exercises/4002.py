# پارامترها

# Objects :
print("halo world 2023")

# Sep :
print("halo", "world", sep="-")

# End :
print("halo,", end="")
print("world")

# flush :
print("immediate Output", flush=True)

# file :
with open('Output.txt', 'w') as f:
    print("Hello, File!", file=f)

name = "Alice"
age = 30
print("Name:", name, " Age:", age)
