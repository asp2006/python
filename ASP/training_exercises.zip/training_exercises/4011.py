seasons = [1, 2, 3, 4, 5]
print(seasons[0])
print(seasons[3])

numbers = [1, 2, 3, 4, ...]
print(numbers)

drinks = ["hipe", "glory", "monster"]
print(drinks)

str_int = [1, "word", 2]
print(str_int)

three = [[1, 2], ["S", "N"], ["list"]]
print(three)

vacant = []
print(vacant)

print(numbers[0])
print(numbers[3])

asus = ("vivobook"[5])
print(asus)

letters = ["a", "c"]
letters.insert(1, "b")
print(letters)

letter = ["a", "b", "b"]
letter.remove("b")
print(letter)

lenn = [[], [], [], [], []]
print(len(lenn))

year = [6, 0, 0, 2]
year.reverse()
print(year)

letters = ["d", "c", "z", "a", "b",]
letters.sort()
print(letters)

a = [1, 2, 2, 3, 4]
del a[2]
print(a)
