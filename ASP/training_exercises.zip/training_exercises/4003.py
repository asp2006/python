#متغیر های رشته ای
bookName = "Learning Python"
the_auther = "Ali Salemi"
publisher = "Iran ublications"

#متغیر های عددی
pages = 350
year_of_publication = 2024
price = 50000

#متغیر های منطقی
is_available = True
it_has_a_transalator = False
the_book_is_colored = True

# استفاده از متغیرها برای نمایش اطلاعات
print("bookName:" + bookName)
print("the_auther:" + the_auther)
print("publisher:" + publisher)

print("pages:" + str(pages))
print("year_of_publication:" + str(year_of_publication))
print("price:" + str(price))

print("is_available:" + str(is_available))
print("it_has_a_transalator:" + str(it_has_a_transalator))
print("the_book_is_colored:" + str(the_book_is_colored))