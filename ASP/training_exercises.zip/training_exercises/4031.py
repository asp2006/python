# The number of iraninan cities in order
cities = ["Tehran","Mashahd","Isfahan","Karaj","Shiraz"]
for index, city in enumerate(cities, start=1):
    print(f"Number{index} - {city}")