# بررسی سن برای تعیین وضعیت قانونی
age = int(input("enter a number :"))
if age >= 18:
     print("you are an adult.")
else:
    print("you are a minor")

# بررسی وضعیت دمایی
temperature = int(input("status :"))
if temperature > 35:
    print("its too hot")
elif temperature > 25:
    print("its warm")
else:
    print("its cool")